<?php
$title = "Allan De Haan Art, West Coast Interpretational";
$css_file = array('front','jquery-flexslider');
$body_class = 'front';
require_once($_SERVER['DOCUMENT_ROOT']."/_templates/single-col.php");
?>
<?php 
	include_once("_php-get-array.php");
	$cid='0';
	$pid='0';
	$slideshow='1';
?>

    <div id="header">
      <div class="section">
        <div class="z-bot moon"></div>
        <!-- mooooooonn -->
        <div class="z-top goose"></div>
        <!-- goose-->
        <h1><span>A</span>llan De Haan<br />Art</h1>
        <h2>West Coast Interpretational</h2>
      </div>
      <ul class="nav vert color">
        <?php include ($site_nav); ?>
      </ul>
    </div><!--/#header -->
    
<div id="main">
    <div class="section intro">
	<h2 class="accents"><span class="color">Recent Art Work</span></h2>
	  <div class="flexslider">
	   <ul class="slides">
	     <?php	          	
	      	$result = mysql_query("SELECT * FROM paintings WHERE slideshow='".$slideshow."'") 
	      		or die(mysql_error());
	      		
	      	while($row = mysql_fetch_array($result)) {  
	      		//echo("<img src='../".$imgSRC.imgSrcBuilder($row["title"]) .".png' alt='' title='".$row["title"] ."'/>\n");
	  		echo("\t\t\t".
	      		"<li>\n".
	      		"\t\t\t\t".
	      		"<a href='/details/?pid=".$row['pid']."'>".
	      		"<img src='/" .$imgSRC. imgSrcBuilder($row["title"]) .".png'"." alt='' />\n".
	      		"</a>".
	      		"\t\t\t\t".
	      		"<p class='flex-caption'>".
	      		"<a href='/details/?pid=".
	      		$row['pid']."'>" . $row['title'] . "</a>"."</p>\n".
	      		"\t\t\t".
	      		"</li>\n\n"
	      		);	
	        }
	    ?>   
	       </ul>       
	  </div>
    </div>
		
	<!--<div class="section" id="events">
		<ul>
			<li>
			<h3><a href="#">Latte One</a></h3>
			<p>Victoria, BC<br>
			250-598-2796</p>	
				<div class="post-date start">
					<p class="month">Jun</p>
					<p class="day">01</p>
				</div>
				
				<div class="post-date end">
					<p class="month">Jun</p>
					<p class="day">30</p>
	            </div>
			</li>
			
			<li>
			<h3><a href="#">Moka House @ Shoal Point</a></h3>
			<p>Victoria, BC<br>
			250-298-8452</p>	
				<div class="post-date start">
					<p class="month">Apr</p>
					<p class="day">01</p>
				</div>
				
				<div class="post-date end">
					<p class="month">Apr</p>
					<p class="day">30</p>
				</div>
				
			</li>
			
			<li>
				<h3>Sundance Java Bar</h3>
			<p>Campbell River, BC
			<br>250-923-2736</p>
				<div class="post-date start">
					<p class="month">Feb</p>
					<p class="day">11</p>
				</div>
				
				<div class="post-date end">
					<p class="month">Mar</p>
					<p class="day">15</p>
				</div>
			</li>
		</ul>
	</div>   -->    
	<div class="section-empty z-bot">&nbsp;</div>
</div> <!-- /#main -->

	<div id="footer">
		<div class="section">
		  <ul class="nav hori color">
		    <?php include ($site_nav); ?>
		  </ul>
		
<?php
$js_file = array('jquery.flexslider-min','front');
include_once($template_footer);
?>
