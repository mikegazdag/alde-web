!function ($) {

  $(function(){

	$('a[href=#top]').click(function(){ //Scroll to Top
		$('html').animate({scrollTop: 0}, 'slow');
		return false;
	});

//	$('form').submit(function() {
//		var valid = true;
//		
//		$(this).find('.error').remove();
//		
//		if(!/^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test($.trim($('.user-email').val()))) {
//			valid = false;
//			$('<div class="error">You need to enter a proper email address</div>').hide().fadeIn().insertAfter(this);
//			
//		}
//		return valid;
//	});
//	
//	default input textfields
//	$(".user-email").focus(function(srcc)
//    {
//        if ($(this).val() == $(this)[0].title)
//        {
//            $(this).removeClass("default-text");
//            $(this).val("");
//        }
//    });
//    
//    $(".user-email").blur(function()
//    {
//        if ($(this).val() == "")
//        {
//            $(this).addClass("default-text");
//            $(this).val($(this)[0].title);
//        }
//    });
//    
//    $(".user-email").blur();
//    
//    if ($('body.gallery')[0] ) {
//    $(".gallery #main .section li:odd").addClass('odd');
//	}
//	    
//	if ($('.message')[0] ) {
//		console.log('element found!');
//		$('.message > p').delay(500).fadeOut('slow');
//		$('.message').delay(1000).slideUp('slow');
//	}	
	
});

}(window.jQuery);