<!-- 
Devel notes: 

	-) Will need to make php variable for painting title, for <title> and <h1>
	-) Adde three layers of backgrounds

-->

<?php
//init template & bootstrap
$title = "Shop &amp; Details";
$css_file = array('shop');
$body_class = 'shop';
include_once($_SERVER['DOCUMENT_ROOT'] . "/_templates/single-col.php");

//init clean _GET
include_once($_SERVER['DOCUMENT_ROOT'] . "/_php-get-array.php");

$pid=0;
$pid=from_array($_GET['pid']);
			
$r = mysql_query("SELECT * FROM paintings WHERE pid='".$pid."'") 
	or die(mysql_error());
$d = mysql_fetch_array($r);  
?>

    <div id="header">
      <div class="section">
      		<h1><?php echo($d['title']); ?></h1>
      </div>
      <ul class="nav hori color">
        <?php include ($site_nav); ?>
      </ul>
     
  </div>
    <div id="main">
    	<?php 
    	 
    	 echo("<div class='section'>\n".
    	   	  "\t\t".
    	   	  "<div class='painting'>\n".
    	   	  "\t\t\t".
    	   	  "<img src='../".$imgSRC.imgSrcBuilder($d["title"]) .".png' alt='' title='".$d["title"] ."'/>\n"."</div>".
    	   	  "\t\t\t\t".
 			  //"<p><a href='/gallery/' class='button large'>Gallery &amp; Shop</a></p>\n". 	   	    
    	   	  "\t\t\t\t\t".
    	   	  "<div class='description blob'>\n".
    	   	  "\t\t\t\t\t\t".
    	   	  "<p class='story'>".$d["description"]."</p>\n".
    	   	  "</div>".   	   
    	   "");
    		
    		//if(!empty($pid)) {				  
    		   			  
    		//} else if(empty($pid)) {
    			//echo("Picture set! Will display random picture.");
    			//header("Location: gallery.php");
    			//exit;
    		//}
    		
      ?>
        
      <!--<div class="wrapper-table">
      
     <div class="fi">
     	&nbsp;
     </div> 
      <table>
      	<thead>
      		<tr>
      			<th class="fi">oneone</th>
      		</tr>
      	</thead>
      	<tbody>
      		<tr>
      			<td>oneone</td>
      			<td>oneone</td>
      			<td>oneone</td>
      			<td>oneone</td>
      		</tr>
      		<tr>
      			<td>oneone</td>
      			<td>oneone</td>
      			<td>oneone</td>
      			<td>oneone</td>
      		</tr>
      	</tbody>
      </table>-->
      </div>         
         
      <div class="shooting-stars z-top"></div>
      <div class="tribal z-bot"></div>
      <div class="stars z-mid"></div>
      
      </div>
<div id="footer">
		<div class="section">
		  <ul class="nav hori color">
		    <?php include ($site_nav); ?>
		  </ul>
		
<?php
$js_file = array('jquery.nivo.slider', 'front');
include_once($template_footer);
?>
