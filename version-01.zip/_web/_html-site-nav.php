<!-- /start of content-nav-menu.php -->

<li <?php if($page == '/') {echo ' class="active"';} ?>><a href="/">Home</a></li>
<li <?php if($page == 'gallery') {echo ' class="active"';} ?>><a href="/gallery/" title="">Gallery</a></li>
<li <?php if($page == 'about') {echo ' class="active"';} ?>><a href="/about/" title="">About Me</a></li>
<li <?php if($page == 'about#contact') {echo ' class="active"';} ?>><a href="/about/#contact" title="">Contact</a></li>
<!--<li><a href="/details/?pid=2">Shop page</a></li>-->
