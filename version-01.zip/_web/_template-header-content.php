<?php
$url = parse_url($_SERVER['REQUEST_URI']);
$url_path = $url['path'];
$url_parts = explode('/', preg_replace('|/+|', '/', $url_path));
$page = array_pop($url_parts);
if(!isset($body_class)) {
	$body_class = 'front';
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
	<title><?php if(isset($title)) {echo $title;} else {echo "Allan De Haan Art |";} ?> Allan De Haan Art | Victoria, BC</title>
	<script type="text/javascript">document.documentElement.className = 'js';</script>
	<link rel="shortcut icon" href="<?php $_SERVER['DOCUMENT_ROOT'] ?>/_images/favicon.ico" type="image/png">
	<link type="text/css" rel="stylesheet" media="all" href="<?php $_SERVER['DOCUMENT_ROOT'] ?>/_css/screen.css">
	<?php if(isset($css_file)) {
		if(is_string($css_file)) {
			$css_files = array($css_file);
		} else { $css_files = $css_file;}
	?>
	<?php foreach($css_files as $css_file_array): ?>	
	<link type="text/css" rel="stylesheet" media="all" href="<?php $_SERVER['DOCUMENT_ROOT'] ?>/_css/<?php echo $css_file_array; ?>.css">
		<?php endforeach; ?><?php } ?>
	<?php if(isset($js_lang_vars)): ?>
	<script type="text/javascript">
	var lang = <?php echo json_encode($js_lang_vars); ?>;
	</script>
	<?php endif; ?>
</head>
<body class="<?php echo $body_class; ?>">
<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/_php-bootstrap.php"); ?>
<!-- /end of header.php -->
