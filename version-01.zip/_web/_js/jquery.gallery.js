$(document).ready(function() {
	$("img.lazy").lazyload();
});