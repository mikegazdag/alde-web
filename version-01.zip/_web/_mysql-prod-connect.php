<?php
	mysql_connect("localhost", "ormazzic_alde", "drivingtocampbellriver") or die(mysql_error());
	mysql_select_db("ormazzic_alde") or die(mysql_error());
	$table = 'paintings';   
?>
