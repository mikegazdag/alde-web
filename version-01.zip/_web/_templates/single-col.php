<?php 
	include_once($_SERVER['DOCUMENT_ROOT'] . "/_template-header-content.php"); ?>
<div id="wrapper"><!-- /end single-canvas.php-->