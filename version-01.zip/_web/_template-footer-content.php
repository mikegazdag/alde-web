		<!-- /start of footer -->
		<div class="legal-message">
			<p>All images &trade; <?php echo date("Y"); ?> ALLaN DE HAaN. All Rights Reserved.</p>
		</div>

	</div><!-- /.section-->
</div><!-- /#footer -->
<?php if(isset($js_file)) {
	if(is_string($js_file)) {
		$js_files = array($js_file);
	} else {
		$js_files = $js_file;
	}	
?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<?php foreach($js_files as $js_file): ?>
<script type="text/javascript" src="/_js/<?php echo $js_file; ?>.js"></script>
<?php endforeach; ?>
<?php } ?>
<script type="text/javascript" src="/_js/utils.js"></script>
<script type="text/javascript">
  var _gaq = _gaq || [];_gaq.push(['_setAccount', 'UA-29049040-1']);_gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>
