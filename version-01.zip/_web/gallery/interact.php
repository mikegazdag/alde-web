
<!-- 
Devel notes: 

	-) Add MySQL - PHP
	-) PHP to assign Title tag, id to .figure,
		-> PHP -- load all id's into array, give 1 of 10 position possibilites

-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>North West Interpretational Allan De Haan Art | Victoria, BC</title>

<script type="text/javascript">defaultocument.documentElement.className = 'js';</script>

<link rel="shortcut icon" href="/_images/favicon.ico" type="image/png">
<link type="text/css" rel="stylesheet" media="all" href="/_css/screen.css">
	
<link type="text/css" rel="stylesheet" media="all" href="/_css/gallery.css">
	
</head>
<body class="gallery">
<!-- bootstrap loaded --><!-- /end of header.php -->
<div id="wrapper"><!-- /end single-canvas.php-->

<div id="header">
      <div class="section">
        <h1><span>N</span>orth West</h1>
        <h2 class="color">Interpretational Art</h2>
      </div>
      <ul class="nav hori color">
        <!-- /start of content-nav-menu.php -->

<li ><a href="/">Home</a></li>
<li ><a href="/gallery/" title="">Gallery &amp; Shop</a></li>
<li ><a href="/about/" title="">About Me</a></li>
<li ><a href="/about/#contact" title="">Contact</a></li>
<li><a href="/details/?pid=2">Shop page</a></li>
      </ul>
</div><!--/#header -->
    
 <div id="main">
      <div class="section">

		<ul class="arrange">
<!-- Dynamtics bits -->        
		<li>
			<div class='figure' id='figure-1'>
				<a href='/details/?pid=1' class='fi'>
					<img src='../_images/pieces/chesterman-beach.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=1' class='se'>Chesterman Beach</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-2'>
				<a href='/details/?pid=2' class='fi'>
					<img src='../_images/pieces/chin-beach-west.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=2' class='se'>Chin Beach West</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-3'>
				<a href='/details/?pid=3' class='fi'>
					<img src='../_images/pieces/crest-mt-sunset.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=3' class='se'>Crest Mt. Sunset</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-4'>
				<a href='/details/?pid=4' class='fi'>
					<img src='../_images/pieces/the-hills-of-sooke.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=4' class='se'>The Hills of Sooke</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-5'>
				<a href='/details/?pid=5' class='fi'>
					<img src='../_images/pieces/orca-symmetry.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=5' class='se'>Orca Symmetry</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-6'>
				<a href='/details/?pid=6' class='fi'>
					<img src='../_images/pieces/payzant-creek.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=6' class='se'>Payzant Creek</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-7'>
				<a href='/details/?pid=7' class='fi'>
					<img src='../_images/pieces/plum-crazy.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=7' class='se'>Plum Crazy</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-8'>
				<a href='/details/?pid=8' class='fi'>
					<img src='../_images/pieces/raven-s-roost.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=8' class='se'>Raven's Roost</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-9'>
				<a href='/details/?pid=9' class='fi'>
					<img src='../_images/pieces/silent-shadows.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=9' class='se'>Silent Shadows</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-10'>
				<a href='/details/?pid=10' class='fi'>
					<img src='../_images/pieces/starry-starry-night.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=10' class='se'>Starry Starry Night</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-11'>
				<a href='/details/?pid=11' class='fi'>
					<img src='../_images/pieces/summers-eve.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=11' class='se'>Summers Eve</a>
				</p>
			</div>
		</li>
		<li>
			<div class='figure' id='figure-12'>
				<a href='/details/?pid=12' class='fi'>
					<img src='../_images/pieces/the-watcher.png'alt='' class='painting' />
				</a>
				<p class='figcaption'>
					<a href='/details/?pid=12' class='se'>The Watcher</a>
				</p>
			</div>
		</li>
</ul>
<!--<div class="figure odd">
  <p>
    <img src="../_images/pieces/chesterman-beach.jpg" alt="" /> 
    <a href="" class="figcaption">Lo, the robot walksLo, the robot walksLo, the robot walks</a>
  </p>
</div>-->
	</div>
    <div class="z-bot mountains"></div>
	<div class="z-bot tribal">
		<div class="z-top chairs"></div>
	</div>
	
</div><!-- /#main -->
<div id="footer">
	<div class="section">
	  <ul class="nav hori color">
	    <!-- /start of content-nav-menu.php -->

<li ><a href="/">Home</a></li>
<li ><a href="/gallery/" title="">Gallery &amp; Shop</a></li>
<li ><a href="/about/" title="">About Me</a></li>
<li ><a href="/about/#contact" title="">Contact</a></li>
<li><a href="/details/?pid=2">Shop page</a></li>
	  </ul>

<!-- /start of footer -->
<div class="legal-message">
	<p>All images &trade; 2010 ALLaN DE HAaN. All Rights Reserved.</p>
</div>

</div><!-- /.section-->
</div><!-- /#footer -->


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script type="text/javascript" src="/_js/jquery.nivo.slider.js"></script>
<script type="text/javascript" src="/_js/utils.js"></script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '????']);
  _gaq.push(['_trackPageview']);
  (function() { var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true; ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);})();
</script>

		<script type="text/javascript" src="/_js/jquery.nivo.slider.js"></script>
			<script type="text/javascript" src="/_js/front.js"></script>
	

</body>
</html>
