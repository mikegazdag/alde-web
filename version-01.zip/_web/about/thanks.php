<?php
$title = "Thank you! |";
$css_file = array('about');
$body_class = 'about';
include_once($_SERVER['DOCUMENT_ROOT'] . "/_templates/single-col.php");
?>

<?php 
 require_once('mail.php');

 // First we set the to address. I would not let anyone put in a to 
 // address in a web form, and neither should you.
 $to = 'al@allandehaan.com';

 // Then we get the information we need from the $_POST array.
 // This step is not necessary, but in a production environment, 
 // we would process and sanitize this data here, rather than 
 // passing raw post data to the class.
 if (isset($_POST['email'])) {
 	$from = $_POST['email'];
 	$subject = "New email from $from"; 
 }
 
 if (isset($_POST['user-message'])) {
 	$body = $_POST['user-message'];
 }
 
 
 // Then create the ZFmail object using the information from above
 $mail = new ZFmail($to,$from,$subject,$body);

 // Finally, call the object's send method to deliver the mail.
 $mail->send();	

 ?>

    <div id="header">
      <div class="section">
       
        <h1><span>T</span>hank You!</h1>
      </div>

    </div>
    <div id="body">
      <div class="section" id="story" style="height: 1000px;">
        	<!-- START BLOB -->
        	<h2 class="color" style="padding-top:30px">Gee thanks for getting in touch.</h2>
        	  <p class="story">I'll be replying back within a reasonable amount of time if you require me to.</p>
        	</div>
      </div>
    
  </div>
</div>
<div id="footer">
		<div class="section">
		  <ul class="nav hori color">
		    <?php include ($site_nav); ?>
		  </ul>
<?php
include_once($template_footer);
?>
