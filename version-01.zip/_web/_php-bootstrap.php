<?php
	require_once($_SERVER['DOCUMENT_ROOT']."/_mysql-connect.php");
		
	//global variables
	$galleryPage = "gallery_main"; 
	$imgSRC = '_images/pieces/'; 
	$DOCUMENT_ROOT = '/';	
		
	//Main elements for templates: 	
	$template_bootstrap =  $_SERVER['DOCUMENT_ROOT'] . "/_php-bootstrap.php";
	$template_header = $_SERVER['DOCUMENT_ROOT'] . "/_template-header-content.php";
	$template_footer = $_SERVER['DOCUMENT_ROOT'] . "/_template-footer-content.php";
	$site_header = $_SERVER['DOCUMENT_ROOT'] . "/_templates/header.php";
	$site_nav = $_SERVER['DOCUMENT_ROOT'] . "/_html-site-nav.php";
	
	$site_footer_js = $_SERVER['DOCUMENT_ROOT'] . "/_html-footer-js-utils.php";;
	$site_footer_legal = $_SERVER['DOCUMENT_ROOT'] . "/_html-footer-rights.php";
	$site_template =0;
	
	//Build Path prefix 
	function imgSrcBuilder($pieceTitle) {
		$pieceSRC = strtolower(preg_replace("/[^a-z]+/i", "-", $pieceTitle));
		return $pieceSRC;
	}
?>
<!-- bootstrap loaded -->