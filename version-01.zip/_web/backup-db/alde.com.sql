-- MySQL dump 10.13  Distrib 5.5.29, for Linux (x86_64)
--
-- Host: localhost    Database: ormazzic_alde
-- ------------------------------------------------------
-- Server version	5.5.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gallery_category`
--

DROP TABLE IF EXISTS `gallery_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_category` (
  `category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_category`
--

LOCK TABLES `gallery_category` WRITE;
/*!40000 ALTER TABLE `gallery_category` DISABLE KEYS */;
INSERT INTO `gallery_category` VALUES (1,'My First Gallery');
/*!40000 ALTER TABLE `gallery_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paintings`
--

DROP TABLE IF EXISTS `paintings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paintings` (
  `pid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL DEFAULT '',
  `date_year_created` int(11) NOT NULL,
  `gallery_set` char(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date_added` date NOT NULL,
  `slideshow` tinyint(1) unsigned zerofill NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paintings`
--

LOCK TABLES `paintings` WRITE;
/*!40000 ALTER TABLE `paintings` DISABLE KEYS */;
INSERT INTO `paintings` VALUES (1,'Chesterman Beach',2007,'gallery_main','I remember a time many years ago, driving with my family and friends to Long Beach, a time when you could still drive a car onto the beach and possibly get it stuck in the sand.  Many things in our lives have changed over the years but  time seems to have stood still here as if immortalized with the ocean roar and the  pounding surf  rolling in as the sun turns molten in the distant sky.\r\n\nThis painting was finished early in 2010, I created this painting as part of a set which consists of 6 paintings. This painting was the 2nd in the set and I painted it with acrylic paint on a 24 x 24 in. 1.5 in. deep canvas.','0000-00-00',0),(2,'Chin Beach West',2007,'gallery_main','A few years ago I became very interested in the Juan da Fuca trail and what I remember was breaking out of the forest and into the open, before us was the vast ocean surf pounding the shore below us. We followed the trail down, looking east was Chin Beach. It was here at Chin Beach that we laid down our heavy loads and camped on the beach burning the late night embers and listening to the ocean roll beyond the light of our flickering flame. \n\nThis painting was loosely realized from a picture that I had taken at the moment when we first saw the beach. I completed it early 2009. I painted it with acrylic paint on a 24 x 36 in. 1.5 in. deep canvas.\n','0000-00-00',1),(3,'Crest Mt. Sunset',2008,'gallery_main','This was the first painting that I had created since my grade school art days in Campbell River. I became inspired by a night spent up on Crest Mt. camped out by a pristine sub-alpine lake with no name. It was here that we sat on our rocky shelf overlooking the mountains of Strathcona Park watching the brilliance of the setting sun dazzle our eyes as it melted away into the evening sky, west beyond the town of Gold River.  The whiskey jacks here are not shy and if you have enough food they are your friends for life.  \n\nThis painting is actually made up on 3 panels  painted early in 2009 with acrylic paint. Two 10 x 12 in 1.5 in deep canvases and one 16 x20 in 1.5 deep canvas attached by two 1/4 in. by 1.5 x 42 in. finishing wood painted black. When I started this painting I had no idea where I was going and kept adding panels until it was finished.\n','0000-00-00',0),(4,'The Hills of Sooke',2008,'gallery_main','When I first lived in Victoria my greatest passion the forest was almost lost, consumed by the pulsing energy of the city. The wanting and being in the forest however was always strong and never left me. It was when I started exploring Mt. McDonanld area that my passion for the wilderness grew stronger. It was here that I felt the challenge of the wilderness beating in my heart once again.  \n\nI finish this painting in the spring of 2010. I created this painting as part of a series or set. The set consists of 6 paintings. This painting was the 3rd in the set. I painted it with acrylic paint on a 24 x 24 in. 1.5 in. deep canvas.','0000-00-00',1),(5,'Orca Symmetry',2008,'gallery_main','The orca is unique mammal of the sea in that it is at the very top of the food chain and growing up in Campbell River I often would see pods of killer whales over the years passing through the strait. They always seemed like they were on a mission, moving quickly and fluidly through the water almost cutting it when coming up for air and then back down again all the while keeping a steady pace. I have heard so many stories of their great hunting abilities, social orders and their communication skills that I am inspired to want to learn and understand these, intelligent wonders of nature.  \n\nI created this painting as part of a series or set. The set consists of 6 paintings. This painting was the 5th in the set. I painted it with acrylic paint on a 24 x 24 in. 1.5 in. deep canvas.','0000-00-00',0),(6,'Payzant Creek',2008,'gallery_main','The Juan de Fuca trial has left many impressions on my mind, Payzant Creek is one of them. Although the campsites are nestled away in the forest you could hear the faint sound of pounding surf off in the distance on the ocean shores below. What I liked about this place was the serenity away from the roaring sea where you could hear the wind blowing through the fir needles of the trees as they swayed in the breeze. This image of the ocean was inspired by a picture I took on the trail down to the beach where you could catch peekaboo views o f the ocean waves rippling below.                                                                        \n\nThis painting I painted early in 2010 and is part of a series or set and consists of 6 paintings. This painting was the 1st in the set. I painted it with acrylic paint on a 24 x 24 in. 1.5 in. deep canvas.\n\n','0000-00-00',0),(7,'Plum Crazy',2009,'gallery_main','This painting was rather unique for me in that it came more from my subconscious than my conscious mind as it seemed more about the colours and flow that needed expressing more than anything.  It reminds me of Hairtrigger Lake in the Mt. Washington area, in Paradise Meadows just before you get to Circlet Lake.  Often I have seen the reflections in the water with a light ripple at dusk which touched off my desire to create this image.  From the stillness of my mind serenity spoke.  \n\nThis was my twelfth painting that I finished.  I completed this work at the end of September of 2011.  I painted it with acrylic paint on a 30 x 40 in. 1.5 in. deep canvas.','0000-00-00',1),(8,'Raven\'s Roost',2009,'gallery_main','I have always been fascinated with the raven, for in most part the lore and the haunting mystery that seems to surround this very interesting and intelligent bird.  I have often looked up through the pin drop silence of the forest into the somber dusky sky only to see a raven gliding by silently as if a ghost had flown through my soul.\n\nI wanted to break ground with this painting in that I had not yet painted something in such large proportions and was eager to expand my horizons dimensionally.  I completed this 4th painting in October of 2009 and I painted it with acrylic paint on a 24 x 60 in. 1.5 in. deep canvas.','0000-00-00',0),(9,'Silent Shadows',2010,'gallery_main','I so often remember after a full day of hiking in the summer heat coming down the steep trail into an earth darkened forest as the sun was fading off into the distant horizon.  The smell and the thickness of the trees growth surrounding me and the lonely silence of the evening forest settling into the night was what inspired me to paint this picture.\n\nThis painting was fully realize after a great summer of hiking and kayaking in the summer of 2009.  I painted this painting with acrylic paint on a 24 x 36 in. 1.5 in. deep canvas.','0000-00-00',0),(10,'Starry Starry Night',2010,'gallery_main','How many times have I looked up through the trees into the endless night sky to see the stars and the moon shinning down on me in the mid of a summers eve.  I named this painting Starry Night in recognition of Don McLean\'s song written in tribute to Vincent Van Gogh\'s painting Starry Starry Night as the song conjures up the thoughts of those starry starry nights.\n\nThis painting was finished in February of 2011 and was the 6th and final of the series or set I had conceptualized. It was painted with acrylic on a 24 x 24 in. 1.5 in. deep canvas.','0000-00-00',1),(11,'Summers Eve',2010,'gallery_main','I have heard off in the distance the honking of the Canadian Geese flying low in the dusky summer skies.  The evening heat beading down on them as they keep a brisk pace, looking for their evening resting grounds near a cool placid body of water.  I remember hearing the sound of their beating wings above, effortless  and almost silent as they pass overhead, their honking echoing again off in the distance of the summer evening skies.\n\nThis was my 2nd painting that I had painted and was created in the early spring of 2009.  I painted it with acrylic paint on a 24 x 36 in. 1.5 in canvas.\n','0000-00-00',0),(12,'The Watcher',2010,'gallery_main','Expanding my knowledge of the Sooke Hills one day atop of Mt. McDonald I notice that we were not alone. There was a lone raven observing us from atop of a dead tree, watching us intently. It was an interesting moment and day as the air seemed electrified and energized, as the clouds grew dark and ominous, and the afternoon yielded to the evening sky. It was here that the ravens collected and it was here that they did their acrobatics in the skies making their deep clucking sounds before disappeared off into the distant horizon. \n\nThis painting was finished in the summer of 2010, I created this painting as part of a set. which consists of 6 paintings. This painting was the 4th in the set and I painted it with acrylic paint on a 24 x 24 in. 1.5 in. deep canvas.','0000-00-00',0);
/*!40000 ALTER TABLE `paintings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-02 16:49:11
